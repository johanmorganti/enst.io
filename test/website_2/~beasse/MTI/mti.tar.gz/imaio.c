/****************************************************************
 *
 *                  imaio.c
 *
 ****************************************************************/

/* Quelques fonctions d'entree-sortie sur des Images au format
 * .ima .dim
 * voir imiaio.h pour les specifications
 */


#include"imaio.h"
#include <stdio.h>


/* ##########           READ_IMA          ########## */

unsigned char **read_ima(char *name, char *name_dim, int *nlig,
			 int *ncol)
{
  int i,j;
  unsigned char **data;
  unsigned char *buffer;
  FILE *fp;

  /* Reading of the image size */
  fp = fopen(name_dim,"r");
  if (fp==NULL) {
    printf("imaio : read_ima : error openning file %s\n",
	   name_dim);
    return(NULL);
  }
  else
    fscanf( fp, "%d %d", ncol, nlig);
  fclose(fp);

  /* Memory allocation for the data structures */
  buffer = (unsigned char *) malloc((*nlig)*sizeof( unsigned char));

  data = (unsigned char **) malloc((*nlig)*sizeof(unsigned char*));
  for(i=0;i<*nlig;i++)
    data[i]= (unsigned char*) malloc((*ncol)*sizeof(unsigned char));
  
  /* reading of the image data */
  fp = fopen( name,"r");
  if (fp==NULL) {
    printf("imaio : read_ima : error openning file %s\n", name);
    return(NULL);
  }
  else
    for(i=0;i<*nlig;i++) {
      fread( buffer, sizeof(unsigned char), *nlig, fp); 
      for(j=0;j<*ncol;j++)
	data[i][j]=(unsigned char) *(buffer+j);
    }
  fclose(fp);
  free(buffer);

  return(data);
}


/* ##########           WRITE_IMA          ########## */

void write_ima(char *name, char *name_dim, unsigned char **data,
	       int nlig, int ncol)
{
  int i,j;
  FILE *fp;

  fp = fopen(name_dim,"w");
  if (fp==NULL)
    printf("imaio : write_ima : error openning file %s\n",
	   name_dim);
  else
    fprintf( fp, "%d %d", ncol, nlig);
  fclose(fp);
  
  fp = fopen( name,"w");
  if (fp==NULL)
    printf("imaio : write_ima : error openning file %s\n", name);
  else
    for(i=0;i<nlig;i++)
      for(j=0;j<ncol;j++) 
	fwrite(&data[i][j],sizeof(unsigned char),1,fp);
  fclose(fp);
}


/* ##########           READ_RVB          ########## */

unsigned char ***read_rvb(char *name, char *name_dim, int *nlig,
			  int *ncol)
{
  int i,j;
  unsigned char ***data;
  unsigned char *buffer;
  FILE *fp;

  fp = fopen(name_dim,"r");
  if (fp==NULL) {
    printf("imaio : read_rvb: error openning file %s\n",
	   name_dim);
    return(NULL);
  }
  else
    fscanf( fp, "%d %d", ncol, nlig);
  fclose(fp);

  buffer = (unsigned char *) malloc(3*(*nlig)*sizeof(unsigned char));

  data = (unsigned char ***) malloc((*nlig)*sizeof(unsigned char**));
  for(i=0;i<(*nlig);i++)
    data[i]= (unsigned char**) malloc((*ncol)*
				      sizeof(unsigned char*));
  for(i=0;i<(*nlig);i++)
    for(j=0;j<(*ncol);j++)
      data[i][j]= (unsigned char*) malloc(3*sizeof(unsigned char));

  fp = fopen( name,"r");
  if (fp==NULL) {
    printf("imaio : read_rvb : error openning file %s\n", name);
    return(NULL);
  }
  else
    for(i=0;i<*ncol;i++) {
      fread( buffer, sizeof(unsigned char), 3*(*nlig), fp); 
      for(j=0;j<*nlig;j++) {
	data[j][i][0]=(unsigned char) *(buffer+3*j);
	data[j][i][1]=(unsigned char) *(buffer+3*j+1);
	data[j][i][2]=(unsigned char) *(buffer+3*j+2);
      }
    }
  fclose(fp);
  free(buffer);

  return(data);
}


/* ##########           WRITE_RVB          ########## */

void write_rvb(char *name, char *name_dim, unsigned char ***data,
	       int nlig,int ncol)
{
  int i,j;
  FILE *fp;

  fp = fopen(name_dim,"w");
  if (fp==NULL)
    printf("imaio : write_rvb : error openning file %s\n",
	   name_dim);
  else
    fprintf( fp, "%d %d", ncol, nlig);
  fclose(fp);
  
  fp = fopen( name,"w");
  if (fp==NULL)
    printf("imaio : write_rvb : error openning file %s\n", name);
  else
    for(i=0;i<ncol;i++)
      for(j=0;j<nlig;j++) {
	fwrite(&data[j][i][0],sizeof(unsigned char),1,fp);
	fwrite(&data[j][i][1],sizeof(unsigned char),1,fp);
	fwrite(&data[j][i][2],sizeof(unsigned char),1,fp);
      }
  fclose(fp);
}


/* ##########           READ_CMAP          ########## */

unsigned char **read_cmap(char *name)
{
  register int i,j;
  unsigned char **result;
  unsigned int a;
  FILE *fp;

  /* Memory allocation of the data structures */
  result= (unsigned char**) malloc(256*sizeof(unsigned char*));
  for (i=0;i<256;i++)
    result[i]= (unsigned char*) malloc(3*sizeof(unsigned char));
  for(j=0;j<3;j++) 
    for(i=0;i<256;i++) 
      result[i][j]=0;

  fp= fopen(name,"r");
  if (fp==NULL)
    printf("imaio : read_cmap : error openning file %s\n",
	   name);
  else
    for(j=0;j<3;j++)
      for(i=0;i<256;i++) {
	fscanf(fp,"%d",&a);
	result[i][j]= (unsigned char) a;
      }
  fclose(fp);
  return(result);
}


/* ##########           WRITE_CMAP          ########## */

void write_cmap(char *name, unsigned char **cmap)
{
  register int i,j;
  FILE *fp;

  fp= fopen(name,"w");
  if (fp==NULL)
    printf("imaio : write_cmap : error openning file %s\n",
	   name);
  else
    for(j=0;j<3;j++) {
      for(i=0;i<256;i++) {
	if (cmap[i][j]<10)
	  fprintf(fp,"  ");
	else if (cmap[i][j]<100)
	  fprintf(fp," ");
	fprintf(fp,"%d ",cmap[i][j]);
	if ((i+1)%20==0)
	  fprintf(fp,"\n");
      }
      fprintf(fp,"\n");
    }
  fclose(fp);
}
