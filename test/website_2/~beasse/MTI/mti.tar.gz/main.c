#include<stdio.h> 
#include"imaio.h"
#include"random_thres.h"
#include"histo.h"

main()
{
  /* le nom des differents fichiers d'entree/sortie */
  char name[80]="vlsi.ima";
  char name_dim[80]="vlsi.dim";
  char out[30]="out.ima";
  char out_dim[30]="out.dim";
  char histo_ima[30]="histo.ima";
  char histo_dim[30]="histo.dim";
  int nlig;
  int ncol, i=0, j;
  short *thres;
  unsigned char **data, **histo_im, **out_ima;
  unsigned long *histo;
  unsigned char level;

  data= read_ima(name,name_dim,&nlig,&ncol);

  thres= RSTA(data, nlig, ncol);
  
  /*  i=0;
      while (thres[i]!=999) {
      printf(" %d\n ",thres[i]);
      i++;
  } */

  histo= create_simple_histo(data, nlig, ncol);
  histo_im= create_histo_image(histo);
  i= 0;
  while (thres[i]!=999) {
    for (j=0;j<256;j++)
      histo_im[j][thres[i]]= 128;
    i++;
  }
  write_ima(histo_ima, histo_dim, histo_im,256,256);

  for (i=0;i<nlig;i++)
    for (j=0;j<ncol;j++) {
      level= 0;
      while (thres[level]<data[i][j])
	level++;
      if (thres[level]==999)
	data[i][j]= 255;
      else
	data[i][j]= thres[level];
    }

  write_ima(out, out_dim, data,nlig,ncol);
  
}
  
  
