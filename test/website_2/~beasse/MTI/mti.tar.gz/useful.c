/****************************************************************
 *
 *                  useful.h
 *
 ****************************************************************/

/* Commande de compilation :
 *         cc -c useful.c
 */

/* A few fuctions and macro that are often of some use
 */

#include"useful.h"


/* ##########           TRUE_SEEDED_RANDOM          ########## */
 
unsigned short true_seeded_random(unsigned short boundary, 
         unsigned short seed)
{
  short mask= 0;
  unsigned short result;

  srand(seed);

  while (mask < boundary)
    mask= (mask<<1) +1;

  do {
    result= rand();
    result= result&mask;
  }
  while (result>boundary);

  return(result); 
}


/* ##########           TRUE_RANDOM          ########## */

unsigned short true_random(unsigned short boundary)
{  
  short mask= 0;
  unsigned short result;

  while (mask < boundary)
    mask= (mask<<1) +1;

  do {
    result= rand();
    result= result&mask;
  }
  while (result>boundary);

  return(result); 
}


