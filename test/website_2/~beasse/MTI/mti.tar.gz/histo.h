/****************************************************************
 *
 *                  histo.h
 *
 ****************************************************************/

/* Creation et manipulation d'histogrammes d'images N&B
 */


#define SCALE_LINE 127

/* ##########           CREATE_SIMPLE_HISTO         ########## */

unsigned long *create_simple_histo(unsigned char **ima, int nlig,
				   int ncol);


/* ##########           CREATE_HISTO_IMAGE         ########## */

unsigned char **create_histo_image(unsigned long *histo);
