/****************************************************************
 *
 *                  color_map.h
 *
 ****************************************************************/

/* Quelques fonctions de manipulation de color map
 */


#include"imaio.h"
#include <stdio.h>


/* ##########           IS_BW_CMAP
 *
 *  Tests wether the given color map is that of a B&W image, ie
 * wether the 3 coefs corresponding to a gray level are equal.
 *  ATTENTION : the given color map must be of valid size, ie
 * 256 x 3.
 */

char is_BW_cmap(long **cmap);
