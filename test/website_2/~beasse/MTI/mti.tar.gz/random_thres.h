/****************************************************************
 *
 *                  random_thes.h
 *
 ****************************************************************/

/* Commande de compilation :
 *         cc random_thes.c
 */

/* An implementation of the random threshold algorithm
 */

#define END_LIST 999;

/* ##########      RSTA
 *
 */

short  *RSTA (unsigned char **TAB, int nrow, int ncol);

