/****************************************************************
 *
 *                  histo.c
 *
 ****************************************************************/

/* Creation et manipulation d'histogrammes d'images N&B
 * voir histo.h pour les specifications
 */


#include"histo.h"
#include"imaio.h"
#include"color_map.h"
#include<stdio.h>

#define SCALE_LINE 127

/* ##########           CREATE_SIMPLE_HISTO          ########## */

unsigned long *create_simple_histo(unsigned char **ima, int nlig,
				   int ncol)
{
  register int i,j;
  long *inter;
  unsigned long *result;

  result= (unsigned long*) calloc(256,sizeof(unsigned long));

  for (i=0;i<nlig;i++)
    for (j=0;j<ncol;j++) {
      if (ima[i][j]<256) {
	result[ima[i][j]]++;
      }
      else {
	printf("histo : create_simple_histo : image has more than\
256 gray levels, unable to create histogram\n");
	return(NULL);
      }
    }
  
  return(result);
}

unsigned char **create_histo_image(unsigned long *histo)
{
  register int i,j;
  unsigned char **result;
  unsigned long *inter;
  long max= 0;
  char nbre= 0;

  /* Memory allocation for the result image */
  result= (unsigned char**) malloc(256*sizeof(unsigned char*));
  for (i=0;i<256;i++)
    result[i]= (unsigned char*) calloc(256,sizeof(unsigned char));

  /* "Normalisation" of the histogram */
  inter= (unsigned long*) calloc(256,sizeof(unsigned long));
  
  for (i=0;i<256;i++) {
    inter[i]= histo[i];
    if (histo[i]>max)
      max= histo[i];
  }

  while(max>255) {
    max>>=1;
    nbre ++;
  }
  for (i=0;i<256;i++)
    inter[i]>>=nbre;
  
  /* Histogram creation */
  for(j=0;j<256;j++)
    for(i=0;i<256-inter[j];i++)
      result[i][j]=255;

  /* Let's put some scale lines */
  for(i=0;i<256;i++) {
    result[i][50]= SCALE_LINE;
    result[i][100]= SCALE_LINE;
    result[i][150]= SCALE_LINE;
    result[i][200]= SCALE_LINE;
    result[i][250]= SCALE_LINE;
  }

  for(j=0;j<256;j++) {    
    result[5][j]= SCALE_LINE;
    result[55][j]= SCALE_LINE;
    result[105][j]= SCALE_LINE;
    result[155][j]= SCALE_LINE;
    result[205][j]= SCALE_LINE;
  }

  return(result);
}

/*
main()
{
  char name[80]="/.ima/images2/don_images_1/medical/brain.ima";
  char name_dim[80]="/.ima/images2/don_images_1/medical/brain.dim";
  char out[30]="out.ima";
  char out_dim[30]="out.dim";
  unsigned char **data;
  int nlig;
  int ncol;
  unsigned long *histo;

  data= read_ima(name,name_dim,&nlig,&ncol);

  histo= create_simple_histo(data,nlig,ncol);
  ncol= 256; nlig= 256;
  data= create_histo_image(histo);
   
  write_ima(out,out_dim,data,nlig,ncol);
}
*/
