/****************************************************************
 *
 *                  useful.h
 *
 ****************************************************************/

/* Commande de compilation :
 *         cc -c useful.c
 */

/* A few fuctions and macro that are often of some use
 */


/* ##########           TRUE_RANDOM
 *
 * Returns a random number between 0 and the specified boundary
 * (included).
 * The seeds has to be set beforehand, or will be left at default
 * value (0).
 */  

unsigned short true_random(unsigned short boundary);

 
/* ##########           TRUE_SEEDED_RANDOM
 *
 * Returns a random number between 0 and the specified boundary
 * (included) as above, except that the user can specify the
 * seed of the random.  
 */

unsigned short true_seeded_random(unsigned short boundary, 
				  unsigned short seed);
