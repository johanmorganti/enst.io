/****************************************************************
 *
 *                  imaio.h
 *
 ****************************************************************/

/* Commande de compilation :
 *         cc -c imaio.c
 */

/* Quelques fonctions d'entree-sortie sur des Images au format
 * .ima .dim
 */


/* ##########           READ_IMA
 *
 * This function reads a B&W image in the .ima/.dim file pair 
 * given by name/name_dim. The image is returned in an unsigned
 * char array of dimension nlig.ncol.
 * In case of error in opening any of the files, an error message
 * is printed, and the NULL pointer is returned.
 */

unsigned char **read_ima(char *name, char *name_dim, int *nlig, 
		int *ncol);

/* ##########           WRITE_IMA
 *
 * This function prints the B&W image data of dimension nlig.ncol
 * in the .ima/.dim file pair given by name/name_dim.
 * In case of error in opening any of the files, an error message
 * is printed, and the NULL pointer is returned.
 */

void write_ima(char *name, char *name_dim, unsigned char **data,
	       int nlig, int ncol);


/* ##########           READ_RVB
 *
 * This function reads a RVBimage in the .rvb/.dim file pair 
 * given by name/name_dim. The image is returned in an unsigned
 * char array of dimension nlig.ncol.3.
 * In case of error in opening any of the files, an error message
 * is printed, and the NULL pointer is returned.
 */

unsigned char ***read_rvb(char *name, char *name_dim, int *nlig, 
		int *ncol);

/* ##########           WRITE_RVB
 *
 * This function prints the RVB image data of dimension nlig.ncol
 * in the .rvb/.dim file pair given by name/name_dim.
 * In case of error in opening any of the files, an error message
 * is printed, and the NULL pointer is returned.
 */

void write_rvb(char *name, char *name_dim, unsigned char ***data,
	       int nlig, int ncol);


unsigned char **read_cmap(char *name);

void write_cmap(char *name, unsigned char **cmap);
