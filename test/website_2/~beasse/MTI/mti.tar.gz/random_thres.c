/****************************************************************
 *
 *                  random_thes.c
 *
 ****************************************************************/

/* Commande de compilation :
 *         cc -c useful.o random_thres.c
 */

/* An implementation of the random threshold algorithm
 */

#include <stdio.h>
#include <stdlib.h>
#include "random_thres.h"   
#include "useful.h"

#define VERBOSE 1


/* ##########           TYPES DEFINITIONS          ########## */

typedef struct ct
{
  char N;
  unsigned char val;
  short delta, AA;
  long WC;
  char is_stopped;
  struct ct *prev, *next;
} CT;


/* ##########      LOCAL FUNCTIONS PROTOTYPES      ########## */

static CT* create_thres (unsigned char val, char N, CT* prev);
static void delete_thres (CT* node);
static unsigned char V (short x, short y, unsigned char **TAB,
			int nrow, int ncol);
static CT* find_closest_CT (CT *list, unsigned char sample);
static char global_stop_test (CT *list);
static void termination (CT *list);
static short* create_result (CT *list);


/* ##########     GLOBAL FUNCTIONS DECLARATION     ########## */

/* ##########                  RSTA                ########## */

short *RSTA (unsigned char **TAB, int nrow, int ncol)
{
  long AV=0;
  long iter;
  char Nt, Na, epsilon; 
  float k,alpha;
  int i,j;
  unsigned char a=255, b=0;
  CT *liste, *winner, *inter;
  long x,y;
  char **bool;
  char winner_deleted;
  int truc;

            /**********************************/
	    /*   initialisation phase         */
	    /**********************************/
 if (VERBOSE)
   fprintf(stdout,"\n\n\
=============================================================\n\
RANDOM SAMPLING THRESHOLDING ALGORITHM : VERBOSE MODE OUTPUT.\n\
=============================================================\n\n\
INITIALISATION PHASE\n\n");

 /*srand(1);*/

 /* Calcul de AV */
 for (i=0;i<nrow;i++)
   for (j=0;j<ncol;j++) 
     AV= AV+ V(i,j,TAB,nrow,ncol);
 AV= AV/(nrow*ncol);
 
 /* calcul de a et b */
 for (i=0;i<nrow;i++)
   for (j=0; j<ncol;j++ ) {
     if (TAB[i][j]>b)
       b= TAB[i][j];
     if (TAB[i][j]<a)
       a= TAB[i][j];
   }

 /* calcul de Nt, Na, alpha et k=alpha/Na */
 Nt= (char) (1.*(b-a)/(2*AV)) +1;
 Na= (char) (nrow*ncol*0.002/Nt);
 alpha= 1.*AV/Na;
 k= 100*((float) alpha) /Na;
 if (VERBOSE)
   fprintf(stdout,"AV : %d\na : %d, b : %d\nNt : %d\n\
Na : %d\nalpha : %f\nk : %f\n\n",AV,a,b,Nt,Na,alpha,k);

 /* creation de la liste chainee */
 if (VERBOSE)
   fprintf(stdout,"Creation of the chained list :\n");
 liste= create_thres(0,-1,NULL);
 inter= liste;
 for(i=0;i<Nt;i++)
   inter= create_thres(i*2*AV+a,i,inter);
 
 /* creation de image booleenne init a 0 */
 if (VERBOSE)
   fprintf(stdout,"\nCreation & Initialisation of the \
boolean image\n"); 
 bool= (char**) malloc(nrow*sizeof (char*));
 for (i=0;i<nrow;i++)
     bool[i] = (char*) calloc(ncol, sizeof (unsigned char));
 if (VERBOSE)
   fprintf(stdout,"     Done\n");


	  /*****************************************/
	  /*  The algorithm itself                 */
	  /*****************************************/

 if (VERBOSE)
     fprintf(stdout,"\nENTERING THE ALGORITHM ITSELF \
:\n\n");
 iter=0;

 do {
   iter++;
   if (VERBOSE)
     fprintf(stdout,"@     Loop %d\n",iter);

/* on prend un point au hasard et on s'assure qu'on ne */
/* l'a pas deja pris */
   /*   do {*/
     x= true_random(nrow-1);
     y= true_random(ncol-1);
     /*   } 
   while (bool[x][y]);
   bool[x][y]= 1;*/
   if (VERBOSE)
     fprintf(stdout,"Random sampling : pixel %d,%d = %d\n",
	     x,y,TAB[x][y]);

/*competing process */     
   winner= find_closest_CT(liste, TAB[x][y]);
   if ((abs(winner->val-TAB[x][y]) < AV)&&(!winner->is_stopped))
     {
       /* accumulating process */
       if (VERBOSE)
	 fprintf(stdout,"%d - %d < %d => accumulating \
process :\n",winner->val,TAB[x][y],AV);
       winner->WC++;
       if (TAB[x][y]<winner->val)
	 epsilon= 1;
       else
	 epsilon= -1;
       winner->delta= winner->delta + epsilon;
       if (VERBOSE)
	 fprintf(stdout,"winner->WC= %d, winner->delta= \
%d\n\n",winner->WC,winner->delta);

       /* adjusting process */
       if (!((winner->WC)%Na)) {
	 if (VERBOSE)
	   fprintf(stdout,"Adjusting process :\n");
	 winner->val+= (unsigned char) (winner->delta*alpha);
	 if (VERBOSE)
	   fprintf(stdout,"$New value of the CT %d : %d\n",
		   winner->N,winner->val);
	 
	 winner_deleted= 0;

	 /* if winner isn't the last ... */
	 if (winner->next!=NULL) {
	   /* ... and if it goes beyond its right neighbor */
	   if (winner->val>=winner->next->val) {
	     if (VERBOSE)
	       fprintf(stdout,"Node %d= %d, Node %d= %d :\n", 
		       winner->N,winner->val,winner->next->N,
		       winner->next->val);
	     delete_thres(winner);
	     winner_deleted= 1;
	   }
	 }
	 /* if winner isn't the first ... */
	 if (winner->prev->prev!=NULL) {
	   /* ... and if it goes beyond its left neighbor */
	   if (winner->val<=winner->prev->val) {
	     if (VERBOSE)
	       fprintf(stdout,"Node %d= %d, Node %d= %d :\n", 
		       winner->N,winner->val,winner->prev->N,
		       winner->prev->val);
	     delete_thres(winner);
	     winner_deleted= 1;
	   }
	 }
	 
	 if (!winner_deleted) {
	   winner->AA+= (short) (winner->delta*alpha);
	   winner->delta=0;
	   if (VERBOSE)
	     fprintf(stdout,"Node %d : AA= %d, delta= 0, WC= %d\n",
		     winner->N,winner->AA,winner->WC);
	   /* stopping criterion */	    
	   if ((abs(winner->AA*1.)<=k*winner->WC)||
	       (winner->WC<iter/2000)){
	     if (VERBOSE)
	       fprintf(stdout,"Node %d has reached stopping \
criterion\n", winner->N);
	     winner->is_stopped=1;
	   }
	 }
       }
     }
   if (VERBOSE)
     scanf("%d",&truc);
 }
 while (!(global_stop_test(liste)));
 
 printf("Nombre d'iteration : %d, k= %f\n",iter,k);
 if (VERBOSE)
   fprintf(stdout,"All the nodes were stopped.\n\n\
TERMINATION PHASE\n\n");

 termination(liste);

 return(create_result(liste));
} 

/* ##########      LOCAL FUNCTIONS DECLARATION     ########## */

/* ##########     CREATE_THRES
 *
 * Create a new node in the list used to represent the coarse
 * thesholds
 */

static CT* create_thres (unsigned char val, char N, CT* prev)
{
  CT* new;

  if (VERBOSE)
   fprintf(stdout,"Creation of node %d\n",N);
 
  new=(CT*) malloc(sizeof(CT));
  if (new==NULL)
    printf ("random_thes : create_thres : allocation error");
  
  new->N= N;
  new->val=val;
  new->delta=0;
  new->AA=0;
  new->WC=0;
  new->is_stopped=0;

  new->prev= prev;
  if (prev==NULL)
    new->next= NULL;
  else {
    new->next= prev->next;
    if (prev->next!=NULL)
      prev->next->prev= new;
    prev->next= new;
  }

  if (VERBOSE) {
    if (new->N==-1)
      fprintf(stdout,"     Entrance node created\n");
    else
      fprintf(stdout,"     Node created, prev= %d\n",
	      new->prev->N);
  }

  return (new);
} 


/* ##########     DELETE_THRES
 *
 * Deletes a new node from the list.
 */

/* cette fonction etait completement fausse */
static void delete_thres (CT* node)
{
  if (VERBOSE)
    fprintf(stdout,"Removing node %d\n",node->N);

  node->prev->next= node->next;
  if (node->next!=NULL)
    node->next->prev= node->prev;
  free(node);

  if (VERBOSE)
    fprintf(stdout,"     Node removed\n");
} 


/* ##########     V
 *
 * Computes the value of V (cf the paper), the maximum pixel
 * value in the imediate neighborhood of a given pixel.
 */

static unsigned char V (short x, short y,unsigned char **TAB,
			int nrow, int ncol)
{
  unsigned char result=0;
  register int i,j;
  
  for (i=-1;i<2;i++)
    for (j=-1;j<2;j++)
     if (!(i&&j)&&(x+i>=0)&&(x+i<nrow)&&(y+j>=0)&&(y+j<ncol))
       if (result<abs(TAB[x][y]-TAB[x+i][y+j]))
	 result= abs(TAB[x][y]-TAB[x+i][y+j]);

 return (result);
}
 

/* ##########     FIND_CLOSEST_CT
 *
 * Find the coarse threshold the closest from a random pixel 
 * of value "sample".
 */

static CT *find_closest_CT(CT *list, unsigned char sample)
{
  CT *current= list, *best= NULL;
  short best_gap= 260;
  int i=0;

  if (VERBOSE)
    fprintf(stdout,"Looking for the CT the closest of the sample \
%d :\n",sample);

  while (current->next!=NULL) {
    current= current->next;
    if ((abs(current->val-sample)<best_gap)&&
	(!current->is_stopped)) {
      best= current;
      best_gap= abs(current->val-sample);
    }
    i++;
  }
  
  if (VERBOSE)
    fprintf(stdout,"     result : CT %d= %d\n",best->N,best->val);

  return(best);
}


/* ##########     GLOBAL_STOP_TEST
 *
 * Tests wether the stop test condition of the algorithm is
 * reached ie wether each coarse theshold has reached his stop
 * condition, and returns a boolean.
 */

static char global_stop_test(CT *list)
{
  char result= 1;
  CT *current= list;

  while (current->next!=NULL) {
    current= current->next;
    if ((!(current->is_stopped))&&(current->WC)) {
      if (VERBOSE)
	fprintf(stdout,"@Node %d= %d (WC= %d)is not stopped yet, \
let's start again !!!\n\n",current->N,current->val,current->WC);
    result=0;
    break;
    }
  }

  return(result);
}


/* ##########     TERMINATION
 *
 * At the end of the algorithm, remove the neigbor(s) of the
 * node that have never won (cf paper).
 */

static void termination(CT *list)
{
  CT *current= list;

  if (VERBOSE)
   fprintf(stdout,"Removing the neighbors of the nodes that \
never won :\n");
  while (current->next!=NULL) {
    current= current->next;
    if (VERBOSE)
      fprintf(stdout,"Node %d : WC= %d\n",current->N,current->WC);
    if (!(current->WC)) {
      if (current->next!=NULL)
	/* if we're not considering the last node */
	delete_thres(current->next);
      if (current->prev->prev!=NULL) 
	/* if the previous isn't the entrance node */
	delete_thres(current->prev);
    }
  }
}


/* ##########     CREATE_RESULT
 *
 * Creates the array where the final threshold will be returned
 * to the caller.
 */

static short *create_result(CT *list)
{
  char number= 0, i=0;
  CT *current= list;
  short *result;

  while (current->next!=NULL) {
    current= current->next;
    number++;
  }

  result= (short*) malloc((number+1)*sizeof(short));

  current= list;
  while (current->next!=NULL) {
    current= current->next;
    result[i]= current->val;
    i++;
  }
  result[number]= END_LIST;

  return(result);
}
